##########Book Management System################
	--- Console "node server.js" to run the file
        --- server listening at localhost 6000.
	--- You can use postman file for Routes which is in same folder name as BookManagement-Postman.json
        --- local mongodb and mongoose are used and the dbs name is "Book_Mng_DB".
        --- There are 5 different collections under "book1" i.e "users" ,"admins" ,"books" ,"likeds", "readlaters".
	--- Used JWT for authentication and authorization.
        --- bcrypt is used to hash/encrypt the user and admin password in the database.
        --- user schema example to test
                {
					"full_name": "akankshagautam",
					"email": "akku04@gmail.com",
					"address": "mumbai",
					"password": "12345678"
				}
        ---- admin schema example to test
				{
					"full_name": "Akanksha Admin",
					"email": "akanksha@gmail.com",
					"address": "mumbai",
					"password": "12345678"
				}
        ---- book schema example to test
                {
					"book_name": "Few things left unsaid",
					"isbn": "12345-484-55885",
					"rating": "5/5"
				}
				
		--- Readlater schema example to test
				{
				  "_id": {
					"$oid": "62b1c5372318ea5252b0a7a4"
				  },
				  "userId": "62b1c3e52318ea5252b0a75b",
				  "bookData": [
					{
					  "data": {
						"_id": {
						  "$oid": "62b1c4452318ea5252b0a76d"
						},
						"Book_Name": "Half Girlfriend ",
						"Isbn": "12345-484-88885",
						"rating": "5/5",
						"__v": 0
					  }
					}
				  ],
				  "__v": 0
				}
				
		--- Like schema example to test
				{
				  "_id": {
					"$oid": "62b1c5372318ea5252b0a7a4"
				  },
				  "userId": "62b1c3e52318ea5252b0a75b",
				  "bookData": [
					{
					  "data": {
						"_id": {
						  "$oid": "62b1c4452318ea5252b0a76d"
						},
						"Book_Name": "Half Girlfriend ",
						"Isbn": "12345-484-88885",
						"rating": "5/5",
						"__v": 0
					  }
					}
				  ],
				  "__v": 0
				}
        

# Use can use postman file for Routes which is in same folder name as BookManagement-Postman.json


--------Show books to user without login ---------------
## 1. output--- will show all the books which are added by admin, so admin have to add books first
        GET--- http://localhost:6000/bookapi/showbooks     



---------Admin Register,Login,logout--------------
## 2.1 output === will register the admin to admin collection
        POST--- http://localhost:6000/bookapi/admin/signup
            ---ALERT its a POST request require body

## 2.2 output === will login the admin after verfying from the admin collection
        POST--- http://localhost:6000/bookapi/admin/signin
            ---ALERT its a POST request require body i.email and password are must

## 2.3 output === will logout the admin
        GET--- http://localhost:6000/bookapi/admin/signout 



----------User Register,Login,logout------------------
## 3.1 output === will register the user to user collection
        POST--- http://localhost:6000/bookapi/user/signup 
            ---ALERT its a POST request require body

## 3.2 output === will login the user after verfying from the user collection
        POST--- http://localhost:6000/bookapi/user/signin
            ---ALERT its a POST request require body i.e userName and password are must

## 3.3 output === will logout the user
        GET--- http://localhost:6000/bookapi/user/signout  
    


---------Admin CRUD on Books i.e Add_book,Show_book,Update_book,Delete_book--------------
## 4.1 output === will add the book to books collection 
        POST--- http://localhost:6000/bookapi/admin/addbook
            ---ALERT its a POST request require body

## 4.2 output === will show the all the book from books collection to admin
        GET--- http://localhost:6000/bookapi/showbooks


## 4.3  output === will update the specific book by id
        PUT--- http://localhost:6000/bookapi/admin/updatebook
            ---ALERT its a PUT request require body parameter which you want to update

## 4.4 output === will delete the specific book
        DELETE--- http://localhost:6000/bookapi/admin/deletebook/:id




---------Admin CRUD on users i.e Show_user,Update_user,Delete_user--------------
## 5.1 output === will show all the user from user collection to admin
        GET--- http://localhost:6000/bookapi/admin/showUsers


## 5.2 output === will update the specific user by id
        PUT--- http://localhost:6000/bookapi/admin/updateUser/:id
            ---ALERT its a PUT request require body parameter which you want to update

## 5.3 output === will delete the specific user by id
        DELETE--- http://localhost:6000/bookapi/admin/deleteUser/:id


---------routes for User to add_to_like, add_to_readlater, see like & readlater section of--------------



-------------------Like & Readlater routes-------------------


## 6.1 output === will add the book to like section of specific user by adding book id
        POST--- http://localhost:6000/bookapi/user/addLiked/:id
            ---ALERT its a PUT request 
            
## 6.2 output === will show the like section of specific user by using JWT token and from then using decoded id i fetched user of logged in user.
        GET--- http://localhost:6000/bookapi/user/showLiked
            
## 6.3 output === will add the book to readLater section of specific user adding book id
        POST--- http://localhost:6000/bookapi/user/addReadLater/:id
            ---ALERT its a PUT request 

## 6.4 output === will show the like section of specific user by using JWT token and from then using decoded id i fetched user of logged in user.
        GET--- http://localhost:6000/bookapi/user/showReadLater
