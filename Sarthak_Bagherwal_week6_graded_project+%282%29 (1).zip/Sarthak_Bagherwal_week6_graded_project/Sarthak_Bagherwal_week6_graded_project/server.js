const express = require("express");
const cookieSession = require("cookie-session");
const dbConfig = require("./app/config/db.config");
const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));


app.use(
  cookieSession({
    name: "Book- Mng-session",
    secret: "COOKIE_SECRET", 
    httpOnly: true
  })
);

const db = require("./app/models");


db.mongoose
  .connect(`mongodb://${dbConfig.HOST}:${dbConfig.PORT}/${dbConfig.DB}`, {
    useNewUrlParser: true,
    useUnifiedTopology: true
  })
  .then(() => {
    console.log("Successfully connect to MongoDB.");
  })
  .catch(err => {
    console.error("Connection error", err);
    process.exit();
  });


require("./app/routes/user.routes")(app);
require("./app/routes/admin.routes")(app);

const PORT = process.env.PORT || 6000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
});


