module.exports = {
    HOST: "localhost",
    PORT: 27017,
    DB: "Book_Mng_DB"
  };