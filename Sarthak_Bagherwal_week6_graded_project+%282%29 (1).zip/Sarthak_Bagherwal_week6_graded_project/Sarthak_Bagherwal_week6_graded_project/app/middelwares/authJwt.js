const jwt = require("jsonwebtoken");
const config = require("../config/auth.config.js");
const db = require("../models");
const User = require("../models/user.model.js");
const admin = db.Admin;
const readLaterDB = db.readLater;
const likeDB = db.liked;
const BookDB = db.book;

verifyToken = (req, res, next) => {
  let token = req.session.token;

  if (!token) {
    return res.status(403).send({ message: "User is not logged in!" });
  }

  jwt.verify(token, config.secret, (err, decoded) => {
    if (err) {
      return res.status(401).send({ message: "Unauthorized!" });
    }
    req.userId = decoded.id;
    next();
  });
};


addLater = (req, res, next) => {
  let token = req.session.token;

  if (!token) {
    return res.status(403).send({ message: "User is not logged in!" });
  }

  jwt.verify(token, config.secret, (err, decoded) => {
    if (err) {
      return res.status(401).send({ message: "Unauthorized!" });
    }

    req.userId = decoded.id;
    User.findOne({
      userId: req.userId,
    })
      .exec((err, userdata) => {
        if (err) {
          res.status(500).send({ message: err });
          return;
        }
        readLaterDB.findOne({
          userId: req.userId,
        })
          .exec((err, user) => {
            if (err) {
              res.status(500).send({ message: err });
              return;
            }

            if (!user) {
              BookDB.findOne({
                _id: req.params.id
              })
                .exec((err, data) => {
                  if (err) {
                    res.status(500).send({ message: err });
                    return;
                  }
                  else {
                    const book = new readLaterDB({
                      userId: req.userId,
                      bookData: { data }
                    });
                    book.save((err) => {
                      if (err) {
                        res.status(500).send({ message: err });
                        return;
                      } else {
                        res.send({
                          username: userdata.full_name,
                          message: "Book is successfully added !"
                        });
                      }
                      return;
                    });
                  }
                });
            }
            else {
              req.userId = decoded.id;
              next();
            }
          });
      });
  });
};

addLike = (req, res, next) => {
  let token = req.session.token;

  if (!token) {
    return res.status(403).send({ message: "User is not logged in!" });
  }

  jwt.verify(token, config.secret, (err, decoded) => {
    if (err) {
      return res.status(401).send({ message: "Unauthorized!" });
    }
    req.userId = decoded.id;
    User.findOne({
      userId: req.userId,
    })
      .exec((err, userdata) => {
        if (err) {
          res.status(500).send({ message: err });
          return;
        }
        likeDB.findOne({
          userId: req.userId,
        })
          .exec((err, user) => {
            if (err) {
              res.status(500).send({ message: err });
              return;
            }

            if (!user) {
              BookDB.findOne({
                _id: req.params.id
              })
                .exec((err, data) => {
                  if (err) {
                    res.status(500).send({ message: err });
                    return;
                  }
                  else {
                    const book = new likeDB({
                      userId: req.userId,
                      bookData: { data }
                    });
                    book.save((err) => {
                      if (err) {
                        res.status(500).send({ message: err });
                        return;
                      } else {
                        res.send({
                          username: userdata.full_name,
                          message: "Book is successfully added !"
                        });
                      }
                      return;
                    });
                  }
                });
            }
            else {
              req.userId = decoded.id;
              next();
            }
          });
      });
  });
};

checkRole = (req, res, next) => {
  let token = req.session.token;

  if (!token) {
    return res.status(403).send({ message: "User is not logged in!" });
  }

  jwt.verify(token, config.secret, (err, decoded) => {
    if (err) {
      return res.status(401).send({ message: "Unauthorized!" });
    }
    else {
      req.userId = decoded.id;
      admin.findById({ _id: req.userId }).exec((err, admin) => {
        if (err) {
          res.status(500).send({ error:err });
          return;
        }
        if(!admin){
          res.send({message: "Require Admin Access"})
        }
        else {
          next();
        }
      })
    }
  });
};

const authJwt = {
  verifyToken,
  addLike,
  addLater,
  checkRole
};
module.exports = authJwt;
