const { authJwt, verifySignUp } = require("../middelwares");
const controller = require("../controllers/admin.controller");

module.exports = function(app) {
  app.use(function(req, res, next) {
    res.header(
      "Access-Control-Allow-Headers",
      "Origin, Content-Type, Accept"
    );
    next();
  });

  app.post("/bookapi/admin/signup",verifySignUp.verifyAdmin,controller.signup);
  app.post("/bookapi/admin/signin", controller.signin);
  app.post("/bookapi/admin/signout", controller.signout);

  app.post("/bookapi/admin/addbook", authJwt.checkRole , controller.addBook);
  app.get("/bookapi/showbooks", controller.showBook);
  app.put("/bookapi/admin/updatebook/:id", authJwt.checkRole , controller.updateBook);
  app.delete("/bookapi/admin/deletebook/:id", authJwt.checkRole , controller.deleteBook);

  app.get("/bookapi/admin/showUsers",authJwt.checkRole, controller.showUsers);
  app.put("/bookapi/admin/updateUser/:id", authJwt.checkRole , controller.updateUser);
  app.delete("/bookapi/admin/deleteUser/:id", authJwt.checkRole, controller.deleteUser);

};
