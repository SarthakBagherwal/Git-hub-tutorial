const verifySignUp  = require("../middelwares/verifySignUp");
const { authJwt } = require("../middelwares");
const controller = require("../controllers/user.controller");

module.exports = function(app) {
  app.use(function(req, res, next) {
    res.header(
      "Access-Control-Allow-Headers",
      "Origin, Content-Type, Accept"
    );
    next();
  });

  app.post("/bookapi/user/signup",verifySignUp.verifyUser,controller.signup);
  app.post("/bookapi/user/signin", controller.signin);
  app.post("/bookapi/user/signout", controller.signout);

  app.post("/bookapi/user/addReadLater/:id",authJwt.addLater, controller.addReadLater);
  app.post("/bookapi/user/addLiked/:id",authJwt.addLike, controller.addLiked);
  
  app.get("/bookapi/user/showLiked",authJwt.verifyToken, controller.showLiked);
  app.get("/bookapi/user/showReadLater",authJwt.verifyToken, controller.showReadLater);
};
