const mongoose = require("mongoose");

const Admin = mongoose.model(
  "Admin",
  new mongoose.Schema({
    full_name: String,
    email: String,
    mobile: Number,
    address: String,
    password: String
  })
);

module.exports = Admin;
