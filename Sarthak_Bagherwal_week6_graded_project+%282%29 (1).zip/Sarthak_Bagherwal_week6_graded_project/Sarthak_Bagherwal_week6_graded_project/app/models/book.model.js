const mongoose = require("mongoose");

const Book = mongoose.model(
  "Book",
  new mongoose.Schema({
    Book_Name: String,
    Isbn: String,
    rating: String
    })
);

module.exports = Book;
