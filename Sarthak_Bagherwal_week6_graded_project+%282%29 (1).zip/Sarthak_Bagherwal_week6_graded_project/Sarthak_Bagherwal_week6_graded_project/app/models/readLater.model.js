const mongoose = require("mongoose");

const readLater = mongoose.model(
  "readLater",
  new mongoose.Schema({
    userId: String,
    bookData: [Object]
  })
);

module.exports = readLater;
