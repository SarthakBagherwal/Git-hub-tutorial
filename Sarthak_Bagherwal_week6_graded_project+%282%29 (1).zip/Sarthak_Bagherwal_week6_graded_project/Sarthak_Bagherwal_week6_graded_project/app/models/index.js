const mongoose = require('mongoose');
mongoose.Promise = global.Promise;

const db = {};

db.mongoose = mongoose;

db.user = require("./user.model");
db.liked = require("./liked.model");
db.readLater = require("./readLater.model");
db.Admin = require("./admin.model");
db.book = require("./book.model");


module.exports = db;