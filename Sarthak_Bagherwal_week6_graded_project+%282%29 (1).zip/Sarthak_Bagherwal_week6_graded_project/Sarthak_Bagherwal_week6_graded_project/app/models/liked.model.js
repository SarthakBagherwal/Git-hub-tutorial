const mongoose = require("mongoose");

const liked = mongoose.model(
  "liked",
  new mongoose.Schema({
    userId: String,
    bookData: [Object]
  })
);

module.exports = liked;
