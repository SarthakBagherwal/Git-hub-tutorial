const config = require("../config/auth.config");
const db = require("../models");
const Admin = db.Admin;
const Book = db.book;

var jwt = require("jsonwebtoken");
var bcrypt = require("bcryptjs");
const User = require("../models/user.model");

exports.signup = (req, res) => {
  const admin = new Admin({
    full_name: req.body.full_name,
    email: req.body.email,
    number: req.body.number,
    address: req.body.address,
    password: bcrypt.hashSync(req.body.password, 8),
  });

  admin.save((err) => {
    if (err) {
      res.status(500).send({ message: err });
      return;
    }else{
      res.send({ message: "Admin was registered successfully!" });
    }
  });
};

exports.signin = (req, res) => {
  Admin.findOne({
    email: req.body.email,
  })
    .exec((err, admin) => {
      if (err) {
        res.status(500).send({ message: err });
        return;
      }

      if (!admin) {
        return res.status(404).send({ message: "User Not found." });
      }

      var passwordIsValid = bcrypt.compareSync(
        req.body.password,
        admin.password
      );

      if (!passwordIsValid) {
        return res.status(401).send({ message: "Invalid Password!" });
      }

      var token = jwt.sign({ id: admin.id }, config.secret, {
        expiresIn: 86400, 
      });


      req.session.token = token;

      res.status(200).send({
        id: admin._id,
        full_name: admin.full_name,
        email: admin.email,
        number: admin.number,
        address: admin.address
      });
    });
};

exports.signout = async (req, res) => {
  try {
    req.session = null;
    return res.status(200).send({ message: "You've been signed out!" });
  } catch (err) {
    this.next(err);
  }
};

exports.addBook = (req, res) => {
  const book = new Book({
    Book_Name: req.body.book_name,
    Isbn: req.body.isbn,
    rating: req.body.rating
  });

  book.save((err) => {
    if (err) {
      res.status(500).send({ message: err });
      return;
    }else{
      res.send({ message: "Book added successfully!" });
    }
  });
};

exports.showBook = async(req, res) => {
  const books = await Book.find()
  res.send(books);
};

exports.updateBook= async (req, res) => {
  Book.findByIdAndUpdate(req.params.id, req.body, function(err, data) {
        if(err){
          res.status(500).send({ message: err });
        }
        else{
            res.send({message:"Book data updated ",
          data:data});
        }
    });  
}

exports.deleteBook=(req, res)=> {
  Book.findByIdAndDelete((req.params.id), 
  function(err, data) {
    if(err){
      res.status(500).send({ message: err });
    }
    else{
        res.send({
          message:"Book data Deleted ",
          data:data
        });
    }
  });  
}

exports.showUsers= async(req, res)=> {
  const users = await User.find()
  res.send(users);
}

exports.updateUser= async(req, res)=> {
  User.findByIdAndUpdate(req.params.id, req.body, function(err, data) {
    if(err){
      res.status(500).send({ message: err });
    }
    else{
        res.send({message:"User data updated ",
      data:data});
    }
});  
}

exports.deleteUser=(req, res)=> {
  User.findByIdAndDelete((req.params.id), 
  function(err) {
    if(err){
      res.status(500).send({ message: err });
    }
    else{
        res.send({
          message:"User data Deleted "
        });
    }
  });  
}