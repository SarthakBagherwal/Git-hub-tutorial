const config = require("../config/auth.config");
const db = require("../models");
const User = db.user;
const likeDB = db.liked;
const readLaterDB = db.readLater;
const BookDB = db.book;

var jwt = require("jsonwebtoken");
var bcrypt = require("bcryptjs");
const { response } = require("express");

exports.signup = (req, res) => {
  const user = new User({
    full_name: req.body.full_name,
    email: req.body.email,
    number: req.body.number,
    address: req.body.address,
    password: bcrypt.hashSync(req.body.password, 8),
  });

  user.save((err) => {
    if (err) {
      res.status(500).send({ message: err });
      return;
    } else {
      res.send({ message: "User was registered successfully!" });
    }
  });
};

exports.signin = (req, res) => {
  User.findOne({
    email: req.body.email,
  })
    .exec((err, user) => {
      if (err) {
        res.status(500).send({ message: err });
        return;
      }

      if (!user) {
        return res.status(404).send({ message: "User Not found." });
      }

      var passwordIsValid = bcrypt.compareSync(
        req.body.password,
        user.password
      );

      if (!passwordIsValid) {
        return res.status(401).send({ message: "Invalid Password!" });
      }

      var token = jwt.sign({ id: user.id }, config.secret, {
        expiresIn: 86400, // 24 hours
      });


      req.session.token = token;

      res.status(200).send({
        id: user._id,
        full_name: user.full_name,
        email: user.email,
        number: user.number,
        address: user.address
      });
    });
};

exports.signout = async (req, res) => {
  try {
    req.session = null;
    return res.status(200).send({ message: "You've been signed out!" });
  } catch (err) {
    this.next(err);
  }
};


exports.addLiked = (req, res) => {
  User.findOne({
    userId: req.userId,
  })
    .exec((err, userdata) => {
      if (err) {
        res.status(500).send({ message: err });
        return;
      }
      BookDB.findOne({
        _id: req.params.id
      })
        .exec((err, data) => {
          if (err) {
            res.status(500).send({ message: err });
            return;
          }
          else {
            likeDB.updateOne(
              { userId: req.userId },
              { $push: { bookData: data } }
            )
              .then(
                res.send({
                  username: userdata.full_name,
                  message: "Book is successfully added !"
                })
              )
              .catch(err => {
                res.send({ error: err })
              })
          }
        });
    });
};

exports.addReadLater = (req, res) => {
  User.findOne({
    userId: req.userId,
  })
    .exec((err, userdata) => {
      if (err) {
        res.status(500).send({ message: err });
        return;
      }
      BookDB.findOne({
        _id: req.params.id
      })
        .exec((err, data) => {
          if (err) {
            res.status(500).send({ message: err });
            return;
          }
          else {
            readLaterDB.updateOne(
              { userId: req.userId },
              { $push: { bookData: data } }
            )
              .then(
                res.send({ 
                  username: user.full_name,
                  message: "Book is successfully added !" })
              )
              .catch(err => {
                res.send({ error: err })
              })
          }
        });
    });
};

exports.showReadLater = (req, res) => {
  readLaterDB.findOne({
    _id: req.userId
  })
    .exec((err, data) => {
      if (err) {
        res.status(500).send({ message: err });
        return;
      }
      else {
        User.findOne({
          _id: req.userId
        })
          .exec((err, user) => {
            if (err) {
              res.status(500).send({ message: err });
              return;
            }
            else {
              res.send({
                username: user.full_name,
                data: data.bookData
              })
            }
          });
      }
    });
};

exports.showLiked = (req, res) => {
  likeDB.findOne({
    _id: req.userId
  })
    .exec((err, data) => {
      if (err) {
        res.status(500).send({ message: err });
        return;
      }
      else {
        User.findOne({
          _id: req.userId
        })
          .exec((err, user) => {
            if (err) {
              res.status(500).send({ message: err });
              return;
            }
            else {
              res.send({
                username: user.full_name,
                data: data.bookData
              })
            }
          });
      }
    });
};